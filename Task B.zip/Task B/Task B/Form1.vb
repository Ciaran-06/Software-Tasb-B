﻿Imports System.Security.Cryptography.X509Certificates

Public Class Form1

    Public Structure Info
        Dim EntryId As String
        Dim Location As String
        Dim forename As String
        Dim surname As String
        Dim NumJumping As Integer
    End Structure

    Dim my_array(29) As Info
    Dim max As Integer

    Private Sub GetData_Click(sender As Object, e As EventArgs) Handles GetData.Click
        Dim no_of_records As Integer = 0

        Using csvparser As New FileIO.TextFieldParser("D:\School PowerPoints\Exam Stuff\Athletes\athletes.csv")

            csvparser.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.Delimited
            csvparser.Delimiters = New String() {","}
            Dim temp As String()

            While Not csvparser.EndOfData

                temp = csvparser.ReadFields()

                my_array(no_of_records).EntryId = temp(0)
                my_array(no_of_records).Location = temp(1)
                my_array(no_of_records).forename = temp(2)
                my_array(no_of_records).surname = temp(3)
                my_array(no_of_records).NumJumping = temp(4)
                no_of_records += 1

            End While

        End Using

        For loop_counter = 0 To no_of_records - 1
            lstoutput.Items.Add(my_array(loop_counter).EntryId)
            lstoutput.Items.Add(my_array(loop_counter).Location)
            lstoutput.Items.Add(my_array(loop_counter).forename)
            lstoutput.Items.Add(my_array(loop_counter).surname)
            lstoutput.Items.Add(my_array(loop_counter).NumJumping)
        Next

        FileClose()

    End Sub

    Private Sub GenBib_Click(sender As Object, e As EventArgs) Handles GenBib.Click

        Dim file_access As System.IO.StreamWriter
        Dim FrstFore(29) As String
        Dim AsciiVal(29) As Integer

        file_access = My.Computer.FileSystem.OpenTextFileWriter("D:\School PowerPoints\Exam Stuff\Athletes\bibNums.csv", True)

        For counter = 0 To 29

            FrstFore(counter) = Mid(my_array(counter).forename, 1, 1)
            AsciiVal(counter) = Asc(my_array(counter).Location)

        Next

        For counter = 0 To 29

            file_access.WriteLine(my_array(counter).EntryId & "," & FrstFore(counter) & my_array(counter).surname & AsciiVal(counter))

        Next

        file_access.Close()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        max = my_array(0).NumJumping
        For Counter = 0 To 28

            If my_array(Counter).NumJumping > max Then
                max = my_array(Counter).NumJumping
            End If

        Next
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        For counter = 0 To 29

            If my_array(counter).NumJumping = max Then

                MsgBox(my_array(counter).forename & " " & my_array(counter).surname)

            End If
        Next
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim MWinners As Integer
        Dim IWinners As Integer
        Dim KWinners As Integer
        Dim CWinners As Integer
        For counter = 0 To 29

            If my_array(counter).Location = "Motherwell" Then
                MWinners += 1

            ElseIf my_array(counter).Location = "Inverness" Then
                IWinners += 1

            ElseIf my_array(counter).Location = "Kirkcaldy" Then
                KWinners += 1

            ElseIf my_array(counter).Location = "Coatbridge" Then
                CWinners += 1

            End If

        Next

        lstoutput.Items.Add("Motherwell had " & MWinners & " finalists")
        lstoutput.Items.Add("Inverness had " & IWinners & " finalists")
        lstoutput.Items.Add("Kirkcaldy had " & KWinners & " finalists")
        lstoutput.Items.Add("Coatbridge had " & CWinners & " finalists")
    End Sub
End Class
